### :point_right: Collaborative Engagement Partnership [Riverbridge Ventures Platform](http://riverbridgeventures.com/)! :point_left:
