import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FpoPage } from './fpo';

@NgModule({
  declarations: [
    FpoPage,
  ],
  imports: [
    IonicPageModule.forChild(FpoPage),
  ],
})
export class FpoPageModule {}
